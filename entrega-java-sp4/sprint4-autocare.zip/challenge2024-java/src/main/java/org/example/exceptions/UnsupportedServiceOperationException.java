package org.example.exceptions;

public class UnsupportedServiceOperationException extends Exception {
}
