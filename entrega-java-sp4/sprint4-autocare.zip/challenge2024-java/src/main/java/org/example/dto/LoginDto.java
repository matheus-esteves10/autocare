package org.example.dto;

public record LoginDto (String email,
                        String cpf,
                        String senha){
}
