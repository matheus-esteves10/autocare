package org.example.exceptions;

public class NotFoundException extends Exception{
}
