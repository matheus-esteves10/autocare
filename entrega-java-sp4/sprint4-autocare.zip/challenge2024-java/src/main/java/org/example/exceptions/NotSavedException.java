package org.example.exceptions;

public class NotSavedException extends Exception {
}
